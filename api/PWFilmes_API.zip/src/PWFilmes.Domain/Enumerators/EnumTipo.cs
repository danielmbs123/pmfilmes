﻿namespace PWFilmes.Domain.Enumerators;

public enum EnumTipo
{
    TipoA,
    TipoB,
    TipoC
}