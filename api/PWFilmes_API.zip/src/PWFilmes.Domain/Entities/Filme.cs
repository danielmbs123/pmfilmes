﻿using PWFilmes.Domain.Entities.Base;

namespace PWFilmes.Domain.Entities
{
    public class Filme : EntityBase
    {
        public string Nome { get; private set; }
        public string Diretor { get; private set; }
        public string Atores { get; private set; }
        public short AnoLancamento { get; private set; }
        public Guid CategoriaId { get; private set; }
        public virtual Categoria Categoria { get; private set; }

        protected Filme() {}

        public Filme(
            string nome,
            string diretor,
            string atores,
            short anoLancamento,
            Guid categoriaId)
        {
            Id = Guid.NewGuid();
            Nome = nome;
            Diretor = diretor;
            Atores = atores;
            AnoLancamento = anoLancamento;
            CategoriaId = categoriaId;
        }

        public void Atualizar(
            string nome,
            string diretor,
            string atores,
            short anoLancamento,
            Guid categoriaId)
        {
            Nome = nome;
            Diretor = diretor;
            Atores = atores;
            AnoLancamento = anoLancamento;
            CategoriaId = categoriaId;
        }
    }
}
