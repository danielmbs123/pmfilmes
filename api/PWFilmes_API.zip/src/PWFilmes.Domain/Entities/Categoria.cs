﻿using PWFilmes.Domain.Entities.Base;

namespace PWFilmes.Domain.Entities
{
    public class Categoria: EntityBase
    {
        public string Descricao { get; private set; }

        protected Categoria() {}

        public Categoria(string descricao)
        {
            Id = Guid.NewGuid();
            Descricao = descricao;
        }

        public void Atualizar(string descricao)
        {
            Descricao = descricao;
        }
    }
}
