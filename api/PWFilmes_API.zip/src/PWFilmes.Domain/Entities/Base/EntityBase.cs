﻿namespace PWFilmes.Domain.Entities.Base
{
    public class EntityBase
    {
        public Guid Id { get; set; }
    }
}
