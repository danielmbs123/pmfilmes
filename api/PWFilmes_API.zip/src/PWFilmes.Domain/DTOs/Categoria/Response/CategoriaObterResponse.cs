﻿namespace PWFilmes.Domain.DTOs.Categoria.Response;

public class CategoriaObterResponse
{
    public Guid Id { get; set; }
    public string Descricao { get; set; }
}