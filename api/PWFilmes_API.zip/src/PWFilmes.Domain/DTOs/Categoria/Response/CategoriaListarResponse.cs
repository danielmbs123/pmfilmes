﻿namespace PWFilmes.Domain.DTOs.Categoria.Response;

public class CategoriaListarResponse
{
    public Guid Id { get; set; }
    public string Descricao { get; set; }
}