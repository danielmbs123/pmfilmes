﻿namespace PWFilmes.Domain.DTOs.Categoria.Request;

public class CategoriaAdicionarRequest
{
    public string Descricao { get; set; }
}