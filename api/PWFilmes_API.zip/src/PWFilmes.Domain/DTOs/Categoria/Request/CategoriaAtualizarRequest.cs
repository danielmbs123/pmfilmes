﻿namespace PWFilmes.Domain.DTOs.Categoria.Request;

public class CategoriaAtualizarRequest
{
    public Guid Id { get; set; }
    public string Descricao { get; set; }
}