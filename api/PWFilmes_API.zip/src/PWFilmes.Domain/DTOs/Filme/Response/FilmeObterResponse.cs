﻿namespace PWFilmes.Domain.DTOs.Filme.Response;

public class FilmeObterResponse
{
    public Guid Id { get; set; }
    public string Nome { get; set; }
    public string Diretor { get; set; }
    public string Atores { get; set; }
    public short AnoLancamento { get; set; }
    public Guid CategoriaId { get; set; }
}