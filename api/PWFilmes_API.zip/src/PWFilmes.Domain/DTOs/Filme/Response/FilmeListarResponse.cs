﻿namespace PWFilmes.Domain.DTOs.Filme.Response;

public class FilmeListarResponse
{
    public Guid Id { get; set; }
    public string Nome { get; set; }
    public string DescricaoCategoria { get; set; }

}