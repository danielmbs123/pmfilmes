﻿namespace PWFilmes.Domain.DTOs.Usuario.Request;

public class UsuarioAutenticarRequest
{
    public string EmailLogin { get; set; }
    public string Senha { get; set; }
}