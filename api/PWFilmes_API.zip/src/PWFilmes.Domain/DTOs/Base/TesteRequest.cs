﻿namespace PWFilmes.Domain.DTOs.Base;

public class TesteRequest
{
    public string Nome { get; set; }
}