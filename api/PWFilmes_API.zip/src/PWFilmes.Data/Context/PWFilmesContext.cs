﻿using Microsoft.EntityFrameworkCore;
using PWFilmes.Domain.Entities;
using System.Reflection;

namespace PWFilmes.Data.Context
{
    public class PWFilmesContext : DbContext
    {
        public DbSet<Categoria> CategoriaSet { get; set; }
        public DbSet<Filme> FilmeSet { get; set; }
        public DbSet<Usuario> UsuariosSet { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.
            //    ApplyConfiguration(new CategoriaConfiguration());
            //modelBuilder.
            //    ApplyConfiguration(new FilmeConfiguration());

            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //const string conexao = "server=localhost;port=3306;database=PWFilmes;uid=root"; //;password=SENHA_DO_BANCO
            const string conexao = "server=mysql.em3soft.com.br;port=3306;database=em3soft30;uid=em3soft30;password=PwFilmesEtec2024";
            optionsBuilder.UseMySql(conexao, ServerVersion.AutoDetect(conexao));
            base.OnConfiguring(optionsBuilder);
        }
    }
}
